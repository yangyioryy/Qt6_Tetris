#ifndef KEYBOARD_H
#define KEYBOARD_H

#include <QWidget>
#include <QKeyEvent>
#include <QLayout>
#include<QPushButton>
#include<QLabel>
#include <Qt>


class KeyBoard: public QWidget
{
    Q_OBJECT
public:
    explicit KeyBoard(QWidget *parent = nullptr);
    ~KeyBoard();

    static int LEFT;
    static int RIGHT;
    static int FASTDROP;
    static int RLEFT;
    static int RRIGHT;
    static int IKUNING;
    static int PAUSE;
    static int ATBOTTOM;
private:
    QPushButton* leftBt,*rightBt,
                  *rleftBt,*rrightBt,
                  *fastdropBt,*atbottomBt,
                  *pauseBt,*ikunBt;
    QLabel* left,*right,
            *rleft,*rright,
            *fastDrop,*atBottom,
             *pause,*iKun;
    QPushButton* returnMain;             //返回按钮
    QPushButton* currentButton;           //现在要修改的按键
    QLabel *keyPromptLabel;            //提示内容
protected:
    void keyPressEvent(QKeyEvent *event) override;
public:
    void setButtonKey(QPushButton* p,int key);
    void initBtCotent();
signals:
    void returnToMain();
public slots:
    void returnToMainPage();
    void changeKeyBinding();      //改变按键


};


#endif // KEYBOARD_H
