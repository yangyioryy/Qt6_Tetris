#include "keyboard.h"
#include<QInputDialog>
#include<QMessageBox>


int KeyBoard::LEFT = Qt::Key_Left;
int KeyBoard::RIGHT = Qt::Key_Right;
int KeyBoard::FASTDROP = Qt::Key_Down;
int KeyBoard::RLEFT = Qt::Key_A;
int KeyBoard::RRIGHT = Qt::Key_D;
int KeyBoard::IKUNING = Qt::Key_G;
int KeyBoard::PAUSE = Qt::Key_P;
int KeyBoard::ATBOTTOM = Qt::Key_Space;

KeyBoard::KeyBoard(QWidget *parent)
    : QWidget(parent),currentButton(nullptr)
{

//初始化
    leftBt=new QPushButton();rightBt=new QPushButton;
    rleftBt = new QPushButton;rrightBt=new QPushButton;
    fastdropBt=new QPushButton;atbottomBt=new QPushButton;
    pauseBt=new QPushButton;ikunBt=new QPushButton;
    returnMain=new QPushButton("返回菜单");

    left=new QLabel("左移");right=new QLabel("右移");
    rleft=new QLabel("逆旋");rright=new QLabel("顺旋");
    fastDrop=new QLabel("快速降落");atBottom=new QLabel("直接降落");
    pause=new QLabel("暂停游戏");iKun=new QLabel("召唤小助手");

    keyPromptLabel=new QLabel();      //提示框
    keyPromptLabel->setText(tr("请按下你想要的按键"));
    keyPromptLabel->setAlignment(Qt::AlignCenter);
    keyPromptLabel->setStyleSheet("background-color: white; color: black;");
    keyPromptLabel->setGeometry(0,0,200,200);
    keyPromptLabel->setVisible(false);



//布局
    initBtCotent();     //初始化按钮的内容
    QVBoxLayout* mainLayout=new QVBoxLayout(this);
    QHBoxLayout* upLayout=new QHBoxLayout();
    QGridLayout* grid1=new QGridLayout();
    QGridLayout* grid2=new QGridLayout();

    grid1->addWidget(leftBt,0,0);
    grid1->addWidget(left,1,0);
    grid1->addWidget(rightBt,0,1);
    grid1->addWidget(right,1,1);
    grid1->addWidget(fastdropBt,2,0);
    grid1->addWidget(fastDrop,2,1);
    grid1->addWidget(pauseBt,3,0);
    grid1->addWidget(pause,3,1);


    grid2->addWidget(rleftBt,0,0);
    grid2->addWidget(rleft,1,0);
    grid2->addWidget(rrightBt,0,1);
    grid2->addWidget(rright,1,1);
    grid2->addWidget(atbottomBt,2,0);
    grid2->addWidget(atBottom,2,1);
    grid2->addWidget(ikunBt,3,0);
    grid2->addWidget(iKun,3,1);


    upLayout->addLayout(grid1);
    upLayout->addLayout(grid2);
    mainLayout->addLayout(upLayout);
    mainLayout->addWidget(keyPromptLabel);
    mainLayout->addWidget(returnMain,0,Qt::AlignBottom|Qt::AlignRight);
//----------------------


//信号与槽
    connect(returnMain, &QPushButton::clicked, this, &KeyBoard::returnToMainPage);
    connect(leftBt, &QPushButton::clicked, this, &KeyBoard::changeKeyBinding);
    connect(rightBt, &QPushButton::clicked, this, &KeyBoard::changeKeyBinding);
    connect(rleftBt, &QPushButton::clicked, this, &KeyBoard::changeKeyBinding);
    connect(rrightBt, &QPushButton::clicked, this, &KeyBoard::changeKeyBinding);
    connect(fastdropBt, &QPushButton::clicked, this, &KeyBoard::changeKeyBinding);
    connect(atbottomBt, &QPushButton::clicked, this, &KeyBoard::changeKeyBinding);
    connect(pauseBt, &QPushButton::clicked, this, &KeyBoard::changeKeyBinding);
    connect(ikunBt, &QPushButton::clicked, this, &KeyBoard::changeKeyBinding);
}




KeyBoard::~KeyBoard(){}

void KeyBoard::returnToMainPage(){
    emit returnToMain();     //发送返回主菜单的信号，在主菜单窗口被接受
}

void KeyBoard::setButtonKey(QPushButton* p,int key)          //给按钮设置对应键位
{
    p->setText(QKeySequence(key).toString(QKeySequence::NativeText));
}
void KeyBoard::initBtCotent()
{
    setButtonKey(leftBt, LEFT);
    setButtonKey(rightBt, RIGHT);
    setButtonKey(rleftBt, RLEFT);
    setButtonKey(rrightBt, RRIGHT);
    setButtonKey(fastdropBt, FASTDROP);
    setButtonKey(atbottomBt, ATBOTTOM);
    setButtonKey(pauseBt, PAUSE);
    setButtonKey(ikunBt, IKUNING);
 }


 void KeyBoard::changeKeyBinding() {
     if(!currentButton)          //只能一次修改一个
     {
     currentButton = qobject_cast<QPushButton*>(sender());      //当前点击的按钮
     currentButton->setStyleSheet("QPushButton {"
                               "    border-radius: 10px;"  // 圆角边框
                               "    border: 2px solid black;"  // 黑色边框
                               "}");             //修改样式
     keyPromptLabel->setVisible(true);
    setFocus();
     }
 }


 void KeyBoard::keyPressEvent(QKeyEvent *event) {
     if (currentButton) {
         int newKey = event->key();
         if (currentButton == leftBt) LEFT = newKey;
         else if (currentButton == rightBt) RIGHT = newKey;
         else if (currentButton == rleftBt) RLEFT = newKey;
         else if (currentButton == rrightBt) RRIGHT = newKey;
         else if (currentButton == fastdropBt) FASTDROP = newKey;
         else if (currentButton == atbottomBt) ATBOTTOM = newKey;
         else if (currentButton == pauseBt) PAUSE = newKey;
         else if (currentButton == ikunBt) IKUNING = newKey;

         setButtonKey(currentButton, newKey);
         keyPromptLabel->setVisible(false);
         currentButton->setStyleSheet("");  // 恢复默认样式
         currentButton = nullptr;
     }
 }

