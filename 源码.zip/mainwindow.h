#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include<QPushButton>
#include<QLabel>
#include<QVBoxLayout>
#include"gameboard.h"
#include"rankboard.h"
#include<QStackedwidget>
#include"referenceboard.h"
#include <QCoreApplication>

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void WindowToCenter();     //窗口居中函数
    void initializeDatabase();        //初始化数据库
private:
    QLabel* mainImg;
    QPushButton* beginGame;
    QPushButton* rank;
    QPushButton* exit;
    QPushButton* reference;
    QPushButton* keyChange;
    GameBoard* gameboard;
    RankBoard* rankboard;
    ReferenceBoard* referenceboard;
    KeyBoard* keyboard;
    QStackedWidget* stackedWidget;
public slots:
    void toGameBoard();
    void gameExit();
    void toRank();
    void toReference();
    void toKeyChange();
    void toMain();
    void tempInf();       //辅助函数
};
#endif // MAINWINDOW_H
