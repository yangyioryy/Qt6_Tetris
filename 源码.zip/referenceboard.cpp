#include "referenceboard.h"
#include <QTextEdit>
#include<QVBoxLayout>

ReferenceBoard::ReferenceBoard(QWidget *parent)
    : QWidget(parent)

{
    // 创建一个文本编辑框用于显示游戏说明
    QTextEdit *textEdit = new QTextEdit;
    textEdit->setReadOnly(true); // 设置为只读

    // 设置游戏说明文本
    QString gameInstructions =
        "俄罗斯方块游戏说明：\n\n"
        "1. 使用左右方向键控制方块的左右移动。\n\n"
        "2. 使用上A、D方向键旋转方块。\n\n"
        "3. 使用下方向键加速方块下落。\n\n"
        "4. 使用空格键可将方块直接落至底部。\n\n"
        "5. 使用P键可暂停游戏。\n\n"
        "6. 使用G键可召唤“小帮手”跳过当前方块。\n\n"
        "7. 点击玩家排行可查看不同玩家的不同纪录。\n\n"
        "8. 点击退出可退出游戏。\n\n"
        "9. 点击说明可查看游戏说明。\n\n"
        "10.点击键位设置可自定义键位。\n\n"
        "11.游戏设定：初始速度为每500ms下落一格，后每过30s，下落间隔减少50ms。初始消除方块积分为10分，后每过30秒，消除积分增加10分";


    textEdit->setPlainText(gameInstructions);


    //返回按钮
    returnMainPage=new QPushButton("返回菜单");
    connect(returnMainPage, &QPushButton::clicked, this, &ReferenceBoard::returnToMainPage);

    // 布局管理

    QVBoxLayout *layout = new QVBoxLayout;
    layout->addWidget(textEdit);
    layout->addWidget(returnMainPage,0,Qt::AlignBottom|Qt::AlignRight);

    setLayout(layout); // 将布局设置为窗口的布局
}

ReferenceBoard::~ReferenceBoard()
{

}

void ReferenceBoard::returnToMainPage(){
    emit returnToMain();     //发送返回主菜单的信号，在主菜单窗口被接受
}
