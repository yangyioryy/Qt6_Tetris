#include "mainwindow.h"
#include <QPixmap>
#include<QScreen>
#include<QPalette>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{

    setWindowTitle("俄罗斯方块");       //设置标题
    QWidget *widget = new QWidget(this);   // 创建Widget组件存控件，方便用布局
    setWindowIcon(QIcon(":/image/bg1.jpg"));

    // 设置背景图片
    QPalette palette;
    palette.setBrush(QPalette::Window, QBrush(QPixmap(":/image/bg2.jpg").scaled(size(), Qt::IgnoreAspectRatio, Qt::SmoothTransformation)));
    setAutoFillBackground(true);
    setPalette(palette);

    // 控件
    mainImg = new QLabel;
    QPixmap pixmap(":/image/main.jpg");
    QPixmap scaledPixmap = pixmap.scaled(400, 300, Qt::KeepAspectRatio);
    mainImg->setPixmap(scaledPixmap);

    beginGame = new QPushButton("开始游戏");
    rank = new QPushButton("玩家排行");
    exit = new QPushButton("退出游戏");
    reference=new QPushButton("说明");
    keyChange=new QPushButton("键位设置");

    //为按钮添加样式
    QString buttonStyle = "QPushButton {"
                          "background-color:white;"
                          "color: black;"
                          "border: none;"
                          "padding: 10px 20px;"
                          "font-size: 16px;"
                          "border-radius: 5px;"
                          "}"
                          "QPushButton:hover {"
                          "background-color: grey;"
                          "color:white;"
                          "}";

    beginGame->setStyleSheet(buttonStyle);
    rank->setStyleSheet(buttonStyle);
    exit->setStyleSheet(buttonStyle);
    reference->setStyleSheet(buttonStyle);
    keyChange->setStyleSheet(buttonStyle);

    QFont font("Microsoft YaHei", 14, QFont::Bold);
    beginGame->setFont(font);
    rank->setFont(font);
    exit->setFont(font);
    reference->setFont(font);
    keyChange->setFont(font);


    // 主窗口布局
    QVBoxLayout* layout = new QVBoxLayout(widget);
    layout->setContentsMargins(20, 20, 20, 20); // 设置边距
    layout->setSpacing(10); // 设置间距
    layout->addWidget(mainImg);
    layout->addWidget(beginGame);
    layout->addWidget(rank);
    layout->addWidget(keyChange);
    layout->addWidget(reference);
    layout->addWidget(exit);
    initializeDatabase();              //创建数据库
    // QSqlQuery query;
    // query.exec("DELETE FROM players");               //清空数据库中的信息

    //   query.prepare("INSERT INTO players (nickname, score,timestamp) VALUES (:nickname, :score,:timestamp)");
    //   QString timestamp = QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss");
    //   query.bindValue(":nickname", "小丑");
    //   query.bindValue(":score", 666);
    //   query.bindValue(":timestamp", timestamp);
    // query.exec();         // 可插入

    // 其他窗口
    gameboard=nullptr;
    rankboard = new RankBoard();
    referenceboard=new ReferenceBoard();
    keyboard=new KeyBoard();

    stackedWidget = new QStackedWidget(this);
    stackedWidget->addWidget(widget);   // 索引0是主窗口
    stackedWidget->addWidget(rankboard);       // 索引1是排名窗口
    stackedWidget->addWidget(referenceboard);   //索引2是说明窗口
    stackedWidget->addWidget(keyboard);         //索引3是键位窗口
    stackedWidget->setCurrentIndex(0);         // 初始显示主窗口
    setCentralWidget(stackedWidget);           // 将stackedwidget设置为窗口的中心部件

    // 窗口设置
    MainWindow::setFixedSize(400,400);
    WindowToCenter(); //窗口最开始的居中处理

    // 连接对象与槽
    connect(beginGame, &QPushButton::clicked, this, &MainWindow::toGameBoard);
    connect(rank, &QPushButton::clicked, this, &MainWindow::toRank);
    connect(exit, &QPushButton::clicked, this, &MainWindow::gameExit);
    connect(reference,&QPushButton::clicked,this,&MainWindow::toReference);
    connect(keyChange,&QPushButton::clicked,this,&MainWindow::toKeyChange);

    //捕捉其他窗口发送的自定义信号(返回主菜单页面的信号)
    connect(referenceboard,&ReferenceBoard::returnToMain,this,&MainWindow::toMain);
    connect(rankboard,&RankBoard::returnToMain,this,&MainWindow::toMain);
    connect(keyboard,&KeyBoard::returnToMain,this,&MainWindow::toMain);
}

MainWindow::~MainWindow() {}


void MainWindow::WindowToCenter()         //将窗口设为居中
{
    QScreen *screen = QGuiApplication::primaryScreen();   // 获取屏幕的几何信息
    QRect screenGeometry = screen->geometry();
    int x = (screenGeometry.width() - width()) / 2;     // 计算窗口居中显示的位置
    int y = (screenGeometry.height() - height()) / 2;
    move(x, y); // 设置窗口位置为居中
}

void MainWindow::toGameBoard()          //跳转时页面才开始加载
{
    // 更改背景图片
    QPalette palette;
    palette.setBrush(QPalette::Window, QBrush(QPixmap(":/image/bg1.png").scaled(600, 600, Qt::IgnoreAspectRatio, Qt::SmoothTransformation)));
    setAutoFillBackground(true);
    setPalette(palette);

    if (!gameboard) {
        gameboard = new GameBoard();
        stackedWidget->addWidget(gameboard); // 添加游戏窗口到 stackedWidget
        connect(gameboard,&GameBoard::returnToMain,this,&MainWindow::toMain);
    }
    if(QFile::exists("savegame.dat"))
    {
        QMessageBox continueBox;
        continueBox.setText("是否继续游戏?");
        continueBox.setStandardButtons(QMessageBox::Yes | QMessageBox::No);
        continueBox.setDefaultButton(QMessageBox::Yes);

        int ret = continueBox.exec();
        if (ret == QMessageBox::Yes)
        {
            tempInf();
            gameboard->loadGame();
        }
        else
        {
            tempInf();
            gameboard->restartGame();
        }
        QFile::remove("savegame.dat");             //不管是否选择了继续游戏，执行完后都需要对存档文件
    }
    else
    {
        tempInf();
        gameboard->restartGame();
    }


}

void MainWindow::tempInf()    //辅助函数
{
    stackedWidget->setCurrentIndex(stackedWidget->indexOf(gameboard)); // 窗口切换到游戏窗口
    MainWindow::setWindowTitle("游戏中~");

    // 改变窗口大小
    setFixedSize(600,600);
    MainWindow::WindowToCenter();     //窗口居中
    connect(gameboard, &GameBoard::updateSQL, rankboard, &RankBoard::updateSQL); //数据的实时更新
}

void MainWindow::toRank()
{
    MainWindow::setWindowTitle("玩家排行 ^-^");
    stackedWidget->setCurrentIndex(1); // 窗口切换到排名窗口
}

void MainWindow::toReference()
{
    MainWindow::setWindowTitle("游戏说明 @_@");
    stackedWidget->setCurrentIndex(2);   //窗口切换至说明窗口
}

void MainWindow:: toKeyChange()
{
   MainWindow::setWindowTitle("键位设置 ~_~");
    stackedWidget->setCurrentIndex(stackedWidget->indexOf(keyboard));   //窗口切换至键位窗口
}

void MainWindow::gameExit()
{
    close(); // 关闭窗口
}

void MainWindow::toMain()
{
    // 更改背景图片
    QPalette palette;
    palette.setBrush(QPalette::Window, QBrush(QPixmap(":/image/bg2.jpg").scaled(size(), Qt::IgnoreAspectRatio, Qt::SmoothTransformation)));
    setAutoFillBackground(true);
    setPalette(palette);
    stackedWidget->setCurrentIndex(0);      //返回主窗口页面
    setWindowTitle("俄罗斯方块");            //重新更改标题
    setFixedSize(400,400);   //重新更新固定大小
    MainWindow::WindowToCenter();     //窗口居中

}


void MainWindow::initializeDatabase() {         //建立数据库和查询表
        QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
        db.setDatabaseName("game_database.db");

        if (!db.open())
        {
            qDebug() << "Database error occurred:" << db.lastError().text();
            return;
        }

        QSqlQuery query;
        if (!query.exec("CREATE TABLE IF NOT EXISTS players ("
                        "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                        "nickname TEXT, "
                        "score INTEGER, "
                        "timestamp DATETIME DEFAULT CURRENT_TIMESTAMP)")) {
            qDebug() << "Error creating table:" << query.lastError().text();
        } else {
            qDebug() << "Table created successfully or already exists.";
        }
}
