#ifndef REFERENCEBOARD_H
#define REFERENCEBOARD_H

#include <QWidget>
#include<QPushButton>

class ReferenceBoard : public QWidget
{
    Q_OBJECT
public:
    explicit ReferenceBoard(QWidget *parent = nullptr);
    ~ReferenceBoard();
private:
    QPushButton* returnMainPage;
signals:
    void returnToMain();
public slots:
    void returnToMainPage();
};

#endif // REFERENCEBOARD_H
