#ifndef RANKBOARD_H
#define RANKBOARD_H

#include <QWidget>
#include<QPushButton>
#include<QTableView>
#include<QSqlTableModel>
#include<QSqlQuery>
#include<QMessageBox>
#include<QSqlError>

class RankBoard : public QWidget
{
    Q_OBJECT
public:
    explicit RankBoard(QWidget *parent = nullptr);
    ~RankBoard();
    void showPlayerTopScores(const QModelIndex &index);
    void showTopTenPlayers();
private:
    QPushButton* returnMain;
    QSqlTableModel *model;
    QTableView *view;
signals:
    void returnToMain();
public slots:
    void returnToMainPage();
    void updateSQL();
};

#endif // RANKBOARD_H
