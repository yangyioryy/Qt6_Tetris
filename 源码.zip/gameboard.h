#ifndef GAMEBOARD_H
#define GAMEBOARD_H

#include <QWidget>
#include<QLabel>
#include<QMovie>
#include<QPushButton>
#include<QLabel>
#include<QTimer>
#include<QTextEdit>
#include<QKeyEvent>
#include<QMainWindow>
#include<QPropertyAnimation>
#include "Block.h"
#include "keyboard.h"
#include<QInputDialog>
#include<QSqlDatabase>
#include<QSqlQuery>
#include<QSqlError>
#include<QFile>
#include<QMediaPlayer>
#include<QAudioOutput>

class GameBoard : public QWidget
{
    Q_OBJECT

public:
    explicit GameBoard(QWidget *parent = nullptr);
    ~GameBoard();

    Block* randomBlock();           //产生随机方块，设定位置
    void dropDown();         //当前方块的下落
    void atBottom(Block* cur);          //当前方块落至底部的处理（更新board数组，同时除第一个随机方块产生，均需与这个函数有关）
    void deleteLine();                //若最后一行是满的，消除最后一行并上面的所有下降

private:
    //界面元素
    bool fastDrop;              //是否速降
    int tempv;                //速降的临时储存速度
    int v;                   //下降的速度
    int count;               //记录花费的时间
    int rLeftCount;          //记录左旋的次数
    int rRightCount;         //记录右旋的次数
    int flag;                //记录得分
    int value;               //当前积分倍率

    int onMovieFlag;          //标志正在执行动画
    QWidget *gameWidget ;    //游戏界面
    QTimer* timer;           //定时器控制下降
    QTimer* TimeCount;       //计算游戏的时长
    QTimer* downKeyTimer;       //控制速降的定时器
    Block* currentB;            //当前方块
    Block* nextB;               //下一方块
    QLabel* lastingTime;
    QTextEdit* lastingTimeNum;
    QLabel* currentGrades;
    QTextEdit* currentGradesNum;
    QLabel* currentBlock;
    QLabel* curBlock;                 //当前的方块显示
    QLabel* nextBlock;
    QLabel* nexBlock;                 //下一个方块显示
    QPushButton* restartBt;
    QPushButton* stop;
    QPushButton *returnButton ;

    //ikun
    QLabel* gifLabel;
    QMovie* gifMovie;
    QPropertyAnimation* gifAnimation;
    QMediaPlayer* mediaPlayer;
    QAudioOutput* audioOutput;


protected:
     void paintEvent(QPaintEvent* event) override;     // 绘制方块和游戏区域
     void keyPressEvent(QKeyEvent* event) override; // 处理键盘事件
     void keyReleaseEvent(QKeyEvent*event) override; //松开键盘
public:
     bool isGameOver();                     //游戏结束
     void  showGameOverDialog();            //游戏结束后跳出对话框
     void restartGame();                   //选择重新开始
     bool validMove(int newX,int newY);          //移动的合理化监测
     void Move(QString s);                     //这里包含了左旋，右旋，左移，右移的操作

     QPixmap getBlockPixmap(BlockShape shape);        //辅助显示图形函数
     void updateNextBlock();                  //更新下一个方块
     void skipCurrent();                       //ikun跳过
     int ikunPosition();                      //辅助ikun定位至最上面的方块
     void confirmUser();                      //让用户输入昵称
     void savePlayerScore(const QString& nickname,int score);
     QString userNickname;

     void saveGame();                           //对游戏进行存档
     void loadGame();                           //重新加载游戏，即继续游戏
signals:
    void returnToMain();
    void updateSQL();                //对数据库信息的显示进行更新
public slots:
    void returnToMainPage();        //返回主菜单
    void updateTime();              //升级（加速）
    void stopTime();                //停止/继续
    void moveRight();               //被顶的向右移动
};

#endif // GAMEBOARD_H
