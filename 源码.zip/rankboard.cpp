#include "rankboard.h"
#include "QLabel"
#include <QDebug>
#include<QVBoxLayout>
#include<QHeaderView>


RankBoard::RankBoard(QWidget *parent)
    : QWidget(parent)
{
    QSqlDatabase db = QSqlDatabase::database();     //此处同样是与主菜单界面创建的数据库进行连接
    if (!db.isOpen()) {
        qDebug() << "Database error occurred:in rankboard" << db.lastError().text();
        return;
    }

    view = new QTableView;     //Tableview用于展示数据库中的表中数据

    model = new QSqlTableModel;
    model->setTable("players");
    model->select();                        // 显示整张表
    view->setModel(model);
    view->setColumnHidden(0,true);   //隐藏id列

    //设置选择行为和选择模式
    view->setSelectionBehavior(QAbstractItemView::SelectRows);
    view->setSelectionMode(QAbstractItemView::SingleSelection);

    showTopTenPlayers();




   // view->viewport()->update();



    returnMain = new QPushButton("返回", this);        //返回按钮

    QVBoxLayout* mainLayout=new QVBoxLayout(this);
    mainLayout->addWidget(view);
    mainLayout->addWidget(returnMain,0,Qt::AlignBottom|Qt::AlignRight);


    //信号与槽的连接
    connect(view, &QTableView::clicked, this, &RankBoard::showPlayerTopScores);
    connect(returnMain, &QPushButton::clicked, this, &RankBoard::returnToMainPage);
}

RankBoard::~RankBoard() {}

void RankBoard::returnToMainPage() {
    emit returnToMain();     // 发送返回主菜单的信号，在主菜单窗口被接受
}

void RankBoard::showTopTenPlayers() {            //只显示前十名的成绩
    QSqlQuery query;
    if (!query.exec("SELECT DISTINCT nickname, score, timestamp FROM ( SELECT nickname, score, timestamp, RANK() OVER (PARTITION BY nickname ORDER BY score DESC, timestamp DESC) AS rank FROM players) AS ranked_players WHERE rank = 1 ORDER BY score DESC LIMIT 10;"))  //不显示id信息
    {                                                                                          //选择最高分及其对应的时间
        qDebug() << "Query error:" << query.lastError().text();
    } else {
         // 清空当前模型的数据
         model->clear();
         // 设置新的查询结果到模型中
         model->setQuery(std::move(query));
         // 手动设置列宽度
         view->horizontalHeader()->setSectionResizeMode(QHeaderView::Interactive);
         view->horizontalHeader()->resizeSection(1, 90);  // nickname 列宽度
         view->horizontalHeader()->resizeSection(2, 100); // score 列宽度
         view->horizontalHeader()->resizeSection(3, 200); // timestamp 列宽度
         //列宽度的设计无效
         view->viewport()->update();
       // qDebug()<<"显示前十";
}
}
void RankBoard::showPlayerTopScores(const QModelIndex &index) {
    QString nickname = index.sibling(index.row(), 0).data().toString();

    QSqlQuery query;
    query.prepare("SELECT score FROM players WHERE nickname = :nickname ORDER BY score DESC LIMIT 5");
    query.bindValue(":nickname", nickname);
    if (!query.exec()) {
        qDebug() << "Query error:" << query.lastError().text();
    }

    QStringList scores;
    while (query.next()) {
        scores << query.value(0).toString();
    }

    QMessageBox::information(this, tr("玩家纪录"), tr("玩家%1的前五个纪录为:\n%2").arg(nickname, scores.join("\n")));
}

void RankBoard::updateSQL(){              //对数据库信息进行更新
   showTopTenPlayers();               //重新对数据进行筛选
}
