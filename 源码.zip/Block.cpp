#include "Block.h"

Block::Block() {
    setShape(NoShape);
}

Block::Block(BlockShape shape)
{
    setShape(shape);
}

void Block::setShape(BlockShape shape)       //方块形状和颜色的设置
{
    for (int i = 0; i < 4; ++i) {
        for (int j = 0; j < 2; ++j) {
            positions[i][j] = positionsTable[shape][i][j];
        }
    }
    pieceShape = shape;
    //随机颜色
    pieceColor = QColor(QRandomGenerator::global()->bounded(256),QRandomGenerator::global()->bounded(256),QRandomGenerator::global()->bounded(256));
}

void Block::draw(QPainter& painter, int squareWidth, int squareHeight) {

    for (int i = 0; i < 4; ++i) {
        int x = positions[i][0];
        int y = positions[i][1];

        if(x<boardWidth&&y<boardHeight)
        {
            QRect rect(x * squareWidth, y * squareHeight, squareWidth, squareHeight);
            painter.fillRect(rect, pieceColor);
        }
    }

}


QRect Block::geometry()      //返回当前方块对应的矩形区域(以坐标放大至游戏面板大小)
    {
    //找到最边界的x
    int minx=x(0),maxx=x(0);
    for(int i=1;i<4;i++)
    {
      if(x(i)>maxx) maxx=x(i);
      if(x(i)<minx) minx=x(i);
   }


        //找到最边界的y
        int miny=y(0),maxy=y(0);
        for(int i=1;i<4;i++)
        {
            if(y(i)>maxy) maxy=y(i);
            if(y(i)<miny) miny=y(i);
        }
        return QRect(minx*20,miny*20,(maxx-minx)*20,(maxy-miny)*20);

}
