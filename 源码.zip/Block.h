#ifndef BLOCK_H
#define BLOCK_H

#include <QColor>
#include <QString>
#include <QWidget>
#include<QPainter>
#include<QRect>
#include<QRandomGenerator>

enum BlockShape { NoShape, ZShape, SShape, LineShape, TShape, SquareShape, LShape, JLShape,UShape,T1Shape,Square1Shape};

static const int positionsTable[11][4][2] = {
    { { 0, 0 }, { 0, 0 }, { 0, 0 }, { 0, 0 } }, // NoShape
    { { 0, -1 }, { 0, 0 }, { -1, 0 }, { -1, 1 } }, // ZShape
    { { 0, -1 }, { 0, 0 }, { 1, 0 }, { 1, 1 } }, // SShape
    { { 0, -1 }, { 0, 0 }, { 0, 1 }, { 0, 2 } }, // LineShape
    { { -1, 0 }, { 0, 0 }, { 1, 0 }, { 0, 1 } }, // TShape
    { { 0, 0 }, { 1, 0 }, { 0, 1 }, { 1, 1 } }, // SquareShape
    { { -1, -1 }, { 0, -1 }, { 0, 0 }, { 0, 1 } }, // LShape
    { { 1, -1 }, { 0, -1 }, { 0, 0 }, { 0, 1 } } ,// JLShape
    { { -1, -1 } , {0, 0 }, { 1, 0} ,{ 2 , -1 } } ,   //UShape
    { { 0 , 0 } , { 1 , 0 } , { 2 , -1 } ,{2 , 1}} ,   //T1Shape
    { { 0 , 0 }, { 2 , 0 }, { 0 , 2 }, { 2 , 2 }}    // Square1Shape
};


//整个游戏面板的大小
static const int boardWidth=20;
static const int boardHeight=30;
static int board[boardWidth][boardHeight];      //已有方块的位置,将数据公开，便于gameboard访问

class Block
{
public:
    Block();
    Block(BlockShape shape);
    ~Block(){}

    void setShape(BlockShape shape);
    BlockShape shape() { return pieceShape; }
    QColor color()  { return pieceColor; }

    int x(int index) { return positions[index][0]; }
    int y(int index) { return positions[index][1]; }

    void setX(int index, int x) { positions[index][0] = x; }
    void setY(int index, int y) { positions[index][1] = y; }

    QRect geometry();

    void draw(QPainter &painter, int squareWidth, int squareHeight);  // 新增绘制方法
    //相关移动的操作

private:
    void setCoords(int coords[4][2]);
    BlockShape pieceShape;
    QColor pieceColor;
    int positions[4][2];       //当前方块占据的格子
};

#endif
