#include "gameboard.h"
#include <QLayout>
#include <QWidget>
#include<QMessageBox>
#include<QPainter>
#include<QKeyEvent>
#include<QDebug>
#include<QFileInfo>


GameBoard::GameBoard(QWidget *parent)
    : QWidget(parent),fastDrop(false),tempv(1),v(500),count(0),rLeftCount(0),rRightCount(0),flag(0),value(10),onMovieFlag(0)
    ,gifLabel(new QLabel(this)),gifMovie(new QMovie(":/image/ikun2.gif")),gifAnimation(new QPropertyAnimation(gifLabel,"geometry"))
{

    mediaPlayer = new QMediaPlayer;
    audioOutput = new QAudioOutput;

    mediaPlayer->setAudioOutput(audioOutput);
    mediaPlayer->setSource(QUrl("qrc:/image/ikun.mp3"));
    audioOutput->setVolume(40);

    setFocusPolicy(Qt::StrongFocus); //确保小部件能够接收键盘事件
    // 初始化board数组
    for (int i = 0; i < 20; ++i) {
        for (int j = 0; j < 10; ++j) {
            board[i][j] = 0; // 空白位置
        }
    }

    userNickname=nullptr;
    // 左侧游戏区域
    gameWidget = new QWidget(this);
    gameWidget->setFixedSize(boardWidth*20,boardHeight*20);       //游戏面板的大小为（600，400）;
    currentB=randomBlock();       // 生成第一个随机方块（当前方块）

    //ikun初始化
    gifLabel->setMovie(gifMovie);
    gifLabel->hide();


    nextB=randomBlock();          //下一个方块
    //qDebug()<<currentB->shape();
    timer=new QTimer(this);
    connect(timer, &QTimer::timeout, this, &GameBoard::dropDown);
    timer->start(v); // 每500ms下落一次


    // 右侧信息区域
    QWidget *infoWidget = new QWidget(this);
    infoWidget->setStyleSheet("QWidget { background-color: rgba(255, 255, 255, 100); }"); // 设置半透明的白色背景

    // 在这里添加信息界面的控件，例如游戏说明、排行榜、按钮等
    QVBoxLayout* rightLayout=new QVBoxLayout(infoWidget);
    QGridLayout* right_topLayout=new QGridLayout;
    lastingTime=new QLabel("时长：");
    lastingTimeNum=new QTextEdit("0 sec");
    lastingTimeNum->setFixedSize(60, 20); // 设置固定大小
    lastingTimeNum->setReadOnly(true);

    currentGrades=new QLabel("积分：");
    currentGradesNum=new QTextEdit("0");
    currentGradesNum->setFixedSize(60,20);// 设置固定大小
    currentGradesNum->setReadOnly(true);

    currentBlock=new QLabel("当前方块：");
    curBlock=new QLabel(this);
    curBlock->setPixmap(getBlockPixmap(currentB->shape()));    //显示当前方块

    nextBlock=new QLabel("下一方块:");
     nexBlock=new QLabel(this);
    nexBlock->setPixmap(getBlockPixmap(nextB->shape()));    //显示下一方块

     lastingTime->setStyleSheet("QLabel {background-color:white; color: black; font: bold 14px; }");
     currentGrades->setStyleSheet("QLabel { background-color:white;color: black; font: bold 14px; }");
     currentBlock->setStyleSheet("QLabel {background-color:white; color: black; font: bold 14px; }");
     nextBlock->setStyleSheet("QLabel {background-color:white; color: black; font: bold 14px; }");
     lastingTimeNum->setStyleSheet("QTextEdit { background-color: white; color: black; font: bold 12px;  }");
     currentGradesNum->setStyleSheet("QTextEdit { background-color: white; color: black; font: bold 12px;  }");
     curBlock->setStyleSheet("QLabel { background-color: white; }");
     nexBlock->setStyleSheet("QLabel { background-color: white;  }");
     lastingTime->setAlignment(Qt::AlignCenter);
     currentGrades->setAlignment(Qt::AlignCenter);
     currentBlock->setAlignment(Qt::AlignCenter);
     nextBlock->setAlignment(Qt::AlignCenter);

//border: 2px solid #444444; border-radius: 5px;

    // 按钮
    QString buttonStyle = "QPushButton {"
                          "background-color:white;"
                          "color: black;"
                          "border: none;"
                          "padding: 10px 20px;"
                          "font-size: 16px;"
                          "border-radius: 5px;"
                          "}"
                          "QPushButton:hover {"
                          "background-color: grey;"
                          "color:white;"
                          "}";
    restartBt = new QPushButton("重新开始", infoWidget);
    restartBt->setStyleSheet(buttonStyle);
    returnButton = new QPushButton("返回菜单", infoWidget);
    returnButton->setStyleSheet(buttonStyle);
    stop = new QPushButton("暂停", infoWidget);
    stop->setStyleSheet(buttonStyle);

    QFont font("Microsoft YaHei", 14, QFont::Bold);
    restartBt->setFont(font);
    returnButton->setFont(font);
    stop->setFont(font);


    TimeCount=new QTimer(this);
    TimeCount->start(1000);
    //右侧布局
    right_topLayout->addWidget(lastingTime,0,0);
    right_topLayout->addWidget(lastingTimeNum,0,1);
    right_topLayout->addWidget(currentGrades,1,0);
    right_topLayout->addWidget(currentGradesNum,1,1);
    right_topLayout->addWidget(currentBlock,2,0);
    right_topLayout->addWidget(curBlock,2,1);
    right_topLayout->addWidget(nextBlock,3,0);
    right_topLayout->addWidget(nexBlock,3,1);


    rightLayout->addLayout(right_topLayout);
    rightLayout->addWidget(stop);
    rightLayout->addWidget(restartBt);
    rightLayout->addWidget(returnButton);


    // // 分界线
    // QFrame *line = new QFrame();
    // line->setFrameShape(QFrame::VLine);  // 设置为垂直线
    // line->setFrameShadow(QFrame::Sunken);


    // 主布局：水平布局包含左侧游戏区域和右侧信息区域
    QHBoxLayout *mainLayout = new QHBoxLayout(this);
    mainLayout->addWidget(gameWidget, 2);  // 左侧游戏区域占据 2/3 的宽度
   // mainLayout->addWidget(line);
    mainLayout->addWidget(infoWidget, 1);  // 右侧信息区域占据 1/3 的宽度
    this->setLayout(mainLayout);


    // 获取已经打开的数据库连接
    QSqlDatabase db = QSqlDatabase::database("qt_sql_default_connection");     //此处不是重新定义，是与已有数据库进行连接
    if (!db.isOpen()) {
        qDebug() << "Database error occurred:in gameboard" << db.lastError().text();
        return;
    }


    //信号与槽的连接，自定义信号的发送
    downKeyTimer = new QTimer(this);
    connect(downKeyTimer, &QTimer::timeout, this, &GameBoard::dropDown);
    connect(returnButton, &QPushButton::clicked, this, &GameBoard::returnToMainPage);
    connect(TimeCount,&QTimer::timeout,this,&GameBoard::updateTime);
    connect(stop,&QPushButton::clicked,this,&GameBoard::stopTime);
    connect(restartBt,&QPushButton::clicked,this,&GameBoard::restartGame);
}

GameBoard::~GameBoard() {}


//---------------------------------------------------------------------------------------------槽函数
void GameBoard::returnToMainPage(){
    timer->stop();
    TimeCount->stop();            //游戏暂停

    QMessageBox saveBox;
    saveBox.setText("是否保存当前游戏进度");
    saveBox.setStandardButtons(QMessageBox::Yes | QMessageBox::No);
    saveBox.setDefaultButton(QMessageBox::Yes);

    int ret = saveBox.exec();
    if (ret == QMessageBox::Yes) {
        saveGame();
    }

    emit returnToMain();     //发送返回主菜单的信号，在主菜单窗口被接受
}

void GameBoard::updateTime()            //游戏时间，难度，倍率的递增
{
    QString temp;
    lastingTimeNum->setText(temp.setNum(count++)+"  sec");

    if(!(GameBoard::count%30))     //半分钟升级一次
    {
        v-=50;
        if(v>0) timer->start(v);          //速度加快
        else timer->start(1);
        value+=10;                //倍率加10
    }
}
void GameBoard::stopTime()                   //暂停
{
    if(!onMovieFlag)
    {
        if(TimeCount->isActive())  //正在运行
        {
        TimeCount->stop();   //暂停时间
         timer->stop();
         GameBoard::stop->setText("继续");
        }
       else
        {
        TimeCount->start(1000);
        timer->start(v);
        GameBoard::stop->setText("暂停");
        }
    }

}
void GameBoard::moveRight()                   //被往右边顶
{

    // 获取 gifLabel 的矩形区域
    QRect gifRect = gifLabel->geometry();

    // 获取 currentB 的矩形区域
    QRect currentRect = QRect(currentB->geometry());
    if (gifRect.intersects(currentRect))
    {
        // 计算需要移动的距离
        // 将 currentB 向右移动 moveDistance 像素
        for(int i=0;i<4;i++)
        {
            currentB->setX(i,currentB->x(i)+1);                    //直接重叠之后则一格一格动
            update();                                               //更新变动之后的方块位置
        }
       // qDebug()<<"交叉了";
    }
   // qDebug()<<currentB->x(0);

}


//---------------------------------------------------------------------------------方块的移动，旋转，掉落，游戏的暂停

Block* GameBoard::randomBlock()                //产生随机方块
{
    BlockShape randomShape = static_cast<BlockShape>(rand() % 10 + 1); // 生成 1 到 10 的随机整数,对应枚举类型中的方块形状
    Block* temp = new Block(randomShape);           // 随机方块生成
    //处理随机方块的四个方块数据
    for (int i = 0; i < 4; ++i) {
        temp->setX(i, temp->x(i)+10);
        temp->setY(i, temp->y(i));
    }

    return temp;
}

void GameBoard::dropDown()                     //方块的下落
{
    if (!currentB) return;
    bool canMove = true;
    for (int i = 0; i < 4; ++i) {
        int newX = currentB->x(i);
        int newY = currentB->y(i)+1;
        if (!validMove(newX, newY)) {
            canMove = false;
            break;
        }
    }
    if (canMove) {
        for (int i = 0; i < 4; ++i) {
            currentB->setY(i, currentB->y(i) + 1);
        }
    } else {
        atBottom(currentB);
    }
    update();         //此处要随时调用重绘函数
}
void GameBoard::atBottom(Block* cur)          //方块到达最底部(更新board[x][y]，同时更新currentB)
{
    if(v==1)
    {
        int temp=v;         //交换速降速度和现在速度
        v=tempv;
        tempv=temp;
        timer->start(v);
    }
        for (int i = 0; i < 4; ++i) {
            int x = cur->x(i);
            int y = cur->y(i);
            if (y >= 0 && y <boardHeight && x >= 0 && x < boardWidth) {
            board[x][y] =1;
         }
     }
    deleteLine();


     // 检查游戏是否结束
     if (isGameOver()) {     //游戏结束时
         timer->stop();
         TimeCount->stop();
         QString nickname=userNickname;
         bool ok;

         int score = currentGradesNum->toPlainText().toInt(&ok);       //游戏结束时储存玩家的信息
         savePlayerScore(nickname,score);
         emit updateSQL();
         showGameOverDialog();

         return;
     }
     currentB=nextB;
     nextB = randomBlock();
     curBlock->setPixmap(getBlockPixmap(currentB->shape())); // 更新 QLabel 的内容
     nexBlock->setPixmap(getBlockPixmap(nextB->shape()));
     rRightCount = 0;
     rLeftCount = 0;
     timer->start(v);
    update(); // 重新绘制游戏界面

}
void GameBoard::deleteLine()                 //消行
{
    for (int y = boardHeight - 1; y >= 0; --y)
    {
        bool fullLine = true;
        for (int x = 0; x < boardWidth; ++x)   //从最后一行起检查有无满行
        {
            if (board[x][y] == 0)
            {
                fullLine = false;
                break;
            }
        }
        if (fullLine)            //满行则取上一行的状态
        {
            QString temp;
            flag++;
            currentGradesNum->setText(temp.setNum(flag*value));
            for (int yy = y; yy > 0; --yy)
            {
                for (int x = 0; x < boardWidth; ++x)
                {
                    board[x][yy] = board[x][yy - 1];
                }
            }
            for (int x = 0; x < boardWidth; ++x)
            {
                board[x][0] =0;
            }
            ++y; // 重新检查当前行
        }
    }
    update(); // 重新绘制游戏界面
}
//--------------------------------------------------------------------其他函数
bool GameBoard::validMove(int newX, int newY)     //方块移动的合理化检查
{
    // 碰撞检测：检查移动后的新位置是否与其他方块重叠
    for (int i = 0; i < 4; ++i) {
        // 获取移动后的方块坐标
        int blockX = newX;
        int blockY = newY;

        // 检查是否超出边界
        if (blockX < 0 || blockX >= boardWidth || blockY >= boardHeight)
            return false; // 超出边界

        // 检查是否与其他方块重叠，假设使用一个二维数组来表示游戏面板，board[][] 表示已有方块的位置
        if (blockY >= 0 && board[blockX][blockY] != 0)
            return false; // 与其他方块重叠
    }

    return true; // 移动合法
}

void GameBoard::Move(QString s)                    //方块的移动
{
    if (((currentB->shape() == SquareShape)||(currentB->shape() == Square1Shape))&&((s=="rLeft")||(s=="rRight"))) // 方块形状为SquareShape时不进行旋转
        return;

    int newPositions[4][2];

    // 计算新坐标
    if(s=="rLeft")                                         //顺时针转
    {
        // qDebug()<<rLeftCount;
        for (int i = 0; i < 4; ++i) {
            if((rLeftCount-rRightCount)>0)
            {
                if((((rLeftCount-rRightCount)%4)==0))
                {
                    newPositions[i][0] = positionsTable[currentB->shape()][i][0]+(currentB->x(i)+(positionsTable[currentB->shape()][i][1]));
                    newPositions[i][1] = (positionsTable[currentB->shape()][i][1])+(currentB->y(i)-(positionsTable[currentB->shape()][i][0]));
                }
                if((rLeftCount-rRightCount)%4==1)
                {
                    newPositions[i][0] = positionsTable[currentB->shape()][i][1]+(currentB->x(i)-(positionsTable[currentB->shape()][i][0]));
                    newPositions[i][1] = -(positionsTable[currentB->shape()][i][0])+(currentB->y(i)-(positionsTable[currentB->shape()][i][1]));
                }
                if((rLeftCount-rRightCount)%4==2)
                {
                    newPositions[i][0] = -(positionsTable[currentB->shape()][i][0])+(currentB->x(i)-(positionsTable[currentB->shape()][i][1]));
                    newPositions[i][1] = -(positionsTable[currentB->shape()][i][1])+(currentB->y(i)+(positionsTable[currentB->shape()][i][0]));
                }
                if((rLeftCount-rRightCount)%4==3)
                {
                    newPositions[i][0] = -(positionsTable[currentB->shape()][i][1])+(currentB->x(i)+(positionsTable[currentB->shape()][i][0]));
                    newPositions[i][1] = (positionsTable[currentB->shape()][i][0])+(currentB->y(i)+(positionsTable[currentB->shape()][i][1]));
                }
            }
            else
            {
                rLeftCount+=4;i--;
            }
        }
    }
    if(s=="rRight")                                            //逆时针转
    {
        for (int i = 0; i < 4; ++i) {
            if((rRightCount-rLeftCount)>0)
            {
                if((rRightCount-rLeftCount)%4==0)
                {
                    newPositions[i][0] = (positionsTable[currentB->shape()][i][0])+(currentB->x(i)-(positionsTable[currentB->shape()][i][1]));
                    newPositions[i][1] = (positionsTable[currentB->shape()][i][1])+(currentB->y(i)+(positionsTable[currentB->shape()][i][0]));
                }
                if((rRightCount-rLeftCount)%4==1)
                {
                    newPositions[i][0] = -(positionsTable[currentB->shape()][i][1])+(currentB->x(i)-(positionsTable[currentB->shape()][i][0]));
                    newPositions[i][1] = (positionsTable[currentB->shape()][i][0])+(currentB->y(i)-(positionsTable[currentB->shape()][i][1]));
                }
                if((rRightCount-rLeftCount)%4==2)
                {
                    newPositions[i][0] = -(positionsTable[currentB->shape()][i][0])+(currentB->x(i)+(positionsTable[currentB->shape()][i][1]));
                    newPositions[i][1] = -(positionsTable[currentB->shape()][i][1])+(currentB->y(i)-(positionsTable[currentB->shape()][i][0]));
                }
                if((rRightCount-rLeftCount)%4==3)
                {
                    newPositions[i][0] = (positionsTable[currentB->shape()][i][1])+(currentB->x(i)+(positionsTable[currentB->shape()][i][0]));
                    newPositions[i][1] = -(positionsTable[currentB->shape()][i][0])+(currentB->y(i)+(positionsTable[currentB->shape()][i][1]));
                }
            }
            else{
                rRightCount+=4;i--;
            }
        }
    }
    if(s=="left")
    {
        for (int i = 0; i < 4; ++i) {
            newPositions[i][0] = currentB->x(i) - 1;   // 向左移动后的新坐标计算
            newPositions[i][1] = currentB->y(i);
        }
    }
    if(s=="right")
    {
        for (int i = 0; i < 4; ++i) {
            newPositions[i][0] = currentB->x(i) + 1;   // 向右移动后的新坐标计算
            newPositions[i][1] = currentB->y(i);
        }
    }
    // 检查移动后的坐标是否合法
    for (int i = 0; i < 4; ++i) {
        int newX = newPositions[i][0];
        int newY = newPositions[i][1];
        // 添加边界检查和合法性验证
        // 假设边界检查和合法性验证函数为 validMove(newX, newY)
        if (!validMove(newX, newY)) {

            if(s=="rLeft") rLeftCount--;        //若没有旋转，在此处要将旋转次数还原
            if(s=="rRight") rRightCount--;
            return; // 如果旋转后位置不合法，直接返回，不进行旋转
        }
    }
    // 如果所有坐标都合法，更新方块的坐标
    for (int i = 0; i < 4; ++i) {
        currentB->setX(i,newPositions[i][0]);
        currentB->setY(i, newPositions[i][1]);
    }
}
bool GameBoard::isGameOver()                       //判断游戏的结束
{
    for (int i = 0; i < 4; ++i) {
        if (currentB->y(i) < 0) {
            return true;
        }
    }
    return false;
}
void GameBoard::restartGame() {                    //重新开始游戏
    // 重置游戏状态
    for (int i = 0; i < 20; ++i) {
        for (int j = 0; j < 30; ++j) {
         board[i][j] = 0;
        }
    }
    userNickname=nullptr;
    onMovieFlag=0;
    v=400;
    count = 0;
    rLeftCount = 0;
    rRightCount = 0;
    flag = 0;
    value = 10;
    gifLabel->hide();
    lastingTimeNum->setText("0 sec");
    currentGradesNum->setText("0");
    currentB = randomBlock();
    curBlock->setPixmap(getBlockPixmap(currentB->shape()));
    nextB=randomBlock();
    nexBlock->setPixmap(getBlockPixmap(nextB->shape()));
    TimeCount->start(1000);
    timer->start(v);
    update();
    confirmUser();
}
void GameBoard::showGameOverDialog() {
    QMessageBox msgBox;
    msgBox.setWindowTitle("输 ~ _ ~");
    msgBox.setText("游戏结束");
    msgBox.setInformativeText("是否重新开始");

    QPushButton *retryButton = msgBox.addButton(tr("是"), QMessageBox::ActionRole);
    QPushButton *cancelButton = msgBox.addButton(tr("否"), QMessageBox::RejectRole);
    msgBox.setDefaultButton(retryButton);

    msgBox.exec();

    if (msgBox.clickedButton() == retryButton) {
        restartGame();
    } else if (msgBox.clickedButton() == cancelButton) {
       emit returnToMain();    //游戏结束之后就只需要返回就行
    }
}
int GameBoard::ikunPosition(){                  //辅助函数
    //只要满足第0块方块不是最下面的方块就行，最右边都没事,故直接定位至最上方
    int flag=0;
    for(int i=1;i<4;i++)
    {
        if(currentB->y(i)>currentB->y(flag)) flag=i;
    }
    return flag;
}

void GameBoard::skipCurrent()                       //跳过当前方块
{
    onMovieFlag=1;         //标志正在动画
    timer->stop();         //方块停止下降

    //ikun出现
    //gifLabel->setGeometry((currentB->x(0)-5)*20,(currentB->y(0))*20,70,70);
    gifLabel->setGeometry((currentB->x(flag)-5)*20,(currentB->y(flag)-1)*20,70,70);     //在对应方块的左侧出现
    gifMovie->jumpToFrame(0);     //确保每次都从头开始播放
    gifMovie->start();
    gifLabel->show();
    mediaPlayer->play();         //播放音频



    //ikun移动
    gifAnimation->setDuration(3000);        //持续3s
    gifAnimation->setStartValue(QRect((currentB->x(flag)-5)*20,(currentB->y(flag)-1)*20,70,70));
    gifAnimation->setEndValue(QRect((boardWidth-3)*20,(currentB->y(flag)-1)*20,70,70));
    gifAnimation->start();

    connect(gifAnimation, &QPropertyAnimation::finished, this, [this]() {    //动画执行结束的信号传递与接受(该函数中传递，该函数接受)
       // qDebug()<<nextB->shape();
        onMovieFlag=0;               //标志动画结束
        gifLabel->hide();
        mediaPlayer->stop();
        timer->start(v);        //再次启动定时器后，马上就会触发dropdown->atbottom->deleteLine,从而对方块进行更新，花费时间为v
    });



    //方块被顶走
    connect(gifAnimation, &QPropertyAnimation::valueChanged, this, [this]() {
           moveRight();                               // 在动画执行过程中检查并移动 currentB
        // qDebug()<<"你好";
    });



}

void GameBoard::confirmUser(){                      //确认当前用户昵称
    // 创建一个输入对话框
     stopTime();          //弹出对话框时游戏暂停

    bool ok = false;
    QString text;

    // 循环直到用户输入有效昵称
    while (!ok || text.isEmpty()) {
        text = QInputDialog::getText(this, tr("玩家昵称"),
                                     tr("请输入昵称:"),
                                     QLineEdit::Normal, "", &ok);
        if (!ok) {
            // 如果用户尝试取消输入，显示警告信息
            QMessageBox::warning(this, tr(""),
                                 tr("请输入昵称！"));
        } else if (text.isEmpty()) {
            // 如果用户输入为空，显示警告信息
            QMessageBox::warning(this, tr(""),
                                 tr("呢称不可为空，请重新输入"));
        }
    }

    // 处理用户输入的昵称
    QString userNickname = text;
    QMessageBox::information(this, tr("欢迎^_^！"),
                             tr("你的昵称为: %1").arg(userNickname));

    // 存储用户输入的昵称
    this->userNickname = userNickname;
    stopTime();           //重启游戏时间
}

//存档操作
void GameBoard::saveGame() {                                     //将当前状态用文件存储
    QFile file("savegame.dat");
    qDebug()<<QFileInfo("savegame.dat").absoluteFilePath();
    if (file.open(QIODevice::WriteOnly)) {
        QDataStream out(&file);
        //左旋和右旋的次数
        out<<rLeftCount;
        out<<rRightCount;
        // 保存当前方块的位置
        for(int i=0;i<4;i++)
        {
            out << currentB->x(i);
            out << currentB->y(i);

            // qDebug()<<currentB->x(i)<<currentB->y(i);
        }
        //昵称
        out<<userNickname;
        // 保存当前得分
        out << currentGradesNum->toPlainText().toInt();
        // 保存方块的类型
        out << currentB->shape();
        out << nextB->shape();

        // 保存等级
        out << value;

        // 保存堆叠的方块数量
        for (int x = 0; x < boardWidth; ++x) {
            for (int y = 0; y < boardHeight; ++y) {
                out << board[x][y];
            }
        }

        //保存当前时间和速度
        out<<count;
        out<<v;

        file.close();
    }
}
void GameBoard::loadGame() {                                            //重新加载当前的状态
    QFile file("savegame.dat");
    if (file.open(QIODevice::ReadOnly)) {
        QDataStream in(&file);
        //左旋和右旋的次数
        int lcount,rcount;
        in>>lcount;
        in>>rcount;
        this->rLeftCount=lcount;
        this->rRightCount=rcount;

        // 读取当前方块的位置和类型
        timer->stop();
        TimeCount->stop();

        for(int i=0;i<4;i++)
        {
            int x,y;
            in>>x;in>>y;
            // qDebug()<<x<<y;      //位置正确
            currentB->setX(i,x);
            currentB->setY(i,y);
        }
        //昵称
        QString name;    in>>name;
        userNickname=name;

        // 读取当前得分
        int score;
        in >> score;
        currentGradesNum->setText(QString::number(score));

        //方块类型
        BlockShape currentBlockType;
        in >> currentBlockType;
        //currentB->setShape(currentBlockType);              //！对方块图形进行设定时，会改变方块的位置！

        BlockShape nextBlockType;
        in >> nextBlockType;
        //nextB->setShape(nextBlockType);

        curBlock->setPixmap(getBlockPixmap(currentBlockType)); // 更新 QLabel 的内容
        nexBlock->setPixmap(getBlockPixmap(nextBlockType));

        // 读取等级
        int currentLevel;
        in >> currentLevel;
        this->value=currentLevel;
        // 读取堆叠的方块数量
        for (int x = 0; x < boardWidth; ++x) {
            for (int y = 0; y < boardHeight; ++y) {
                in >> board[x][y];
            }
        }
        update();             //重绘图案

        //读取速度和时间
        int count,v;
        in>>count;
        in>>v;
        this->count=count;
        this->v=v;
        this->timer->start(v);            //重新开始计时
        TimeCount->start(1000);

        file.close();
    }
}


void GameBoard::savePlayerScore(const QString &nickname, int score) { //数据的储存
    //插入昵称和分数
    QSqlQuery query;
    query.prepare("INSERT INTO players (nickname, score,timestamp) VALUES (:nickname, :score,:timestamp)");
    QString timestamp = QDateTime::currentDateTime().toString("yyyy-MM-dd hh:mm:ss");
    query.bindValue(":nickname", nickname);
    query.bindValue(":score", score);
    query.bindValue(":timestamp", timestamp);
    if (!query.exec()) {
        qDebug() << "Error inserting into table:" << query.lastError().text();
    }
}


 //显示图形
QPixmap GameBoard::getBlockPixmap(BlockShape shape) {          //通过坐标为方块涂色显示
    int blockSize = 20; // 每个小方块的大小
    QPixmap pixmap(blockSize * 4, blockSize * 4); // 创建一个 4x4 的 QPixmap
    pixmap.fill(Qt::white); // 填充背景为白色

    QPainter painter(&pixmap);
    painter.setBrush(Qt::black); // 设置方块颜色为黑色

    for (int i = 0; i < 4; ++i) {
        int x = positionsTable[shape][i][0] + 1; // 偏移到中心位置
        int y = positionsTable[shape][i][1] + 1;
        painter.drawRect(x * blockSize, y * blockSize, blockSize, blockSize);
    }

    return pixmap;
}

//--------------------------------------------------------- -------------------------------事件绑定

void GameBoard::paintEvent(QPaintEvent*) {               //方块的涂色
    QPainter painter(this);

    // 绘制当前方块
    if (currentB) {
        currentB->draw(painter, 20, 20);  // 调用Block类的绘制方法
    }

    // 绘制固定方块
    for (int x = 0; x < boardWidth; ++x) {
        for (int y = 0; y < boardHeight; ++y) {
            if (board[x][y] != 0) {
                QRect rect(x * 20, y * 20, 20, 20);
                painter.fillRect(rect, Qt::black); //假设固定方块颜色为黑色
            }
        }
    }
}


void GameBoard::keyPressEvent(QKeyEvent *event) {    //键盘事件绑定

   // qDebug()<<event;
    if(event->key()==KeyBoard::LEFT) {
        // 向左移动
        //qDebug()<<"dasfasdfasd";
        Move("left");
        update();
    }
    if(event->key()==KeyBoard::RIGHT)
    {
        // 向右移动
       // qDebug()<<"hahahah";
         Move("right");
        update();
    }
    if(event->key()==KeyBoard::RLEFT)
    {
        rLeftCount++;
        // 逆时针旋转
        Move("rLeft");
        update();
    }
    if(event->key()==KeyBoard:: RRIGHT)
    {
        rRightCount++;
        // 顺时针旋转
        Move("rRight");
        update();
    }
    if(event->key()== KeyBoard::ATBOTTOM)       //速降
    {
        int temp=v;                       //交换速降速度和现在速度
        v=tempv;
        tempv=temp;
        timer->start(v);
    }
    if(event->key()==KeyBoard::PAUSE)
    {
        stopTime();
    }
    if(event->key()==KeyBoard::FASTDROP)
    {

        if(!fastDrop)
        {
        timer->stop();
        fastDrop=true;
        downKeyTimer->start(50);
        }
    }
    if(event->key()==KeyBoard::IKUNING)
    {
        if(!onMovieFlag) skipCurrent();
    }

}

void GameBoard::keyReleaseEvent(QKeyEvent *event)       //键盘释放事件
 {
    if (event->isAutoRepeat())
        return;

    if(event->key()==KeyBoard::FASTDROP)
    {
         fastDrop=false;
         downKeyTimer->stop();
         timer->start(v);
    }
}






